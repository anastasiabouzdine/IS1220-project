/**
 * The package contains all the classes that are 
 * necessary for the GUI.
 * 
 * @author John de Wasseige
 * @author Patrick von Platen
 */
package gui;