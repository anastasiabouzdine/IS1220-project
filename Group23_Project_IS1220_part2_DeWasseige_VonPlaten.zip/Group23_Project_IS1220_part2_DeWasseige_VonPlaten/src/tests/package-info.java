/**
 * This package contains all the JUnit tests used in the project.
 * 
 * 
 * @author John de Wasseige
 * @author Patrick von Platen
 */
package tests;